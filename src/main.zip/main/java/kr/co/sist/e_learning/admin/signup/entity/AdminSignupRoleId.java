package kr.co.sist.e_learning.admin.signup.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Getter;
import lombok.Setter;

@Embeddable
@Getter @Setter
public class AdminSignupRoleId implements Serializable{
	@Column(name = "REQUEST_ID")
    private String requestId;

    @Column(name = "ROLE_CODE")
    private String roleCode;
}
