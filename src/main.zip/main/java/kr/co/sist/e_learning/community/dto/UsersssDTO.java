package kr.co.sist.e_learning.community.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter

public class UsersssDTO {
	 private Integer  userSeq;
	    private String email;
	    private String nickname;
}
