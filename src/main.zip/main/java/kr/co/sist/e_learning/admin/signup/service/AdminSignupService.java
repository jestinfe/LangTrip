package kr.co.sist.e_learning.admin.signup.service;

import kr.co.sist.e_learning.admin.signup.dto.SignupRequestDTO;

import java.util.List;

public interface AdminSignupService {
    List<SignupRequestDTO> getPendingRequests();
    void approveSignupRequest(String requestId);

}
