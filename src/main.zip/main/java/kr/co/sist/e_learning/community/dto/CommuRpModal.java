package kr.co.sist.e_learning.community.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CommuRpModal {
	private Long postId2;
    private Integer reasonChk;
    private String reasonText;
    
    
  
}
