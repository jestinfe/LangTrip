package kr.co.sist.e_learning.admin.signup.service;

import kr.co.sist.e_learning.admin.signup.dto.SignupRequestDTO;
import kr.co.sist.e_learning.admin.signup.entity.AdminSignupRequest;
import kr.co.sist.e_learning.admin.signup.repository.AdminSignupRequestRepository;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AdminSignupServiceImpl implements AdminSignupService {

    @Autowired
    private AdminSignupRequestRepository requestRepository;

    @Override
    public List<SignupRequestDTO> getPendingRequests() {
        List<AdminSignupRequest> pendingRequests = requestRepository.findByStatus("PENDING");

        return pendingRequests.stream().map(request -> {
            SignupRequestDTO dto = new SignupRequestDTO();
            dto.setRequestId(request.getRequestId());
            dto.setAdminName(request.getAdminName());
            dto.setEmail(request.getEmail());
            dto.setPhone(request.getPhone());
            dto.setDept(request.getDept());
            dto.setRequestDate(request.getRequestDate());
            dto.setRoles(request.getRoles().stream()
                .map(role -> role.getId().getRoleCode())
                .collect(Collectors.toList()));
            return dto;
        }).collect(Collectors.toList());
    }
    
    @Transactional
    @Override
    public void approveSignupRequest(String requestId) {
        AdminSignupRequest request = requestRepository.findById(requestId)
            .orElseThrow(() -> new IllegalArgumentException("요청 ID가 존재하지 않습니다: " + requestId));

        // 상태 확인
        if (!"PENDING".equals(request.getStatus())) {
            throw new IllegalStateException("이미 처리된 요청입니다.");
        }

        // 1. 관리자 계정 생성
        Admin admin = new Admin();
        admin.setAdminId(request.getEmail()); // 이메일을 ID로 사용
        admin.setAdminName(request.getAdminName());
        admin.setEmail(request.getEmail());
        admin.setPhone(request.getPhone());
        admin.setPassword(request.getPasswordHash());
        admin.setDept(request.getDept());
        admin.setStatus("Y");
        admin.setRegDate(LocalDateTime.now());
        admin.setCheckAuth("N");
        adminRepository.save(admin);

        // 2. 권한 저장
        List<AdminRole> roles = request.getRoles().stream().map(reqRole -> {
            AdminRole role = new AdminRole();
            role.setAdminId(admin.getAdminId());
            role.setRoleCode(reqRole.getId().getRoleCode());
            return role;
        }).collect(Collectors.toList());
        adminRoleRepository.saveAll(roles);

        // 3. 상태 변경
        request.setStatus("APPROVED");
        requestRepository.save(request);
    }

}
