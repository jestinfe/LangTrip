package kr.co.sist.e_learning.user.auth;

public class FindUsernameResponseDTO {
    private String username;

    public FindUsernameResponseDTO(String username) {
        this.username = username;
    }
}
