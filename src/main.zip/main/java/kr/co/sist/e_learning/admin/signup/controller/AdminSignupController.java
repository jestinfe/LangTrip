package kr.co.sist.e_learning.admin.signup.controller;

import kr.co.sist.e_learning.admin.signup.dto.SignupRequestDTO;
import kr.co.sist.e_learning.admin.signup.service.AdminSignupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class AdminSignupController {

    @Autowired
    private AdminSignupService signupService;

    @GetMapping("/admin/signup/requests")
    public String showSignupRequests(Model model) {
        List<SignupRequestDTO> signupRequests = signupService.getPendingRequests();
        model.addAttribute("signupRequests", signupRequests);
        return "admin/signup_requests";
    }
    
    @PostMapping("/admin/signup/approve")
    public String approveRequest(@RequestParam("requestId") String requestId, RedirectAttributes redirectAttributes) {
        try {
            signupService.approveSignupRequest(requestId);
            redirectAttributes.addFlashAttribute("message", "승인 처리 완료");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "승인 실패: " + e.getMessage());
        }
        return "redirect:/admin/signup/requests";
    }

}
