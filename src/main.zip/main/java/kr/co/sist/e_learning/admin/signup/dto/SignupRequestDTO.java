package kr.co.sist.e_learning.admin.signup.dto;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Getter @Setter
public class SignupRequestDTO {
    private String requestId;
    private String adminName;
    private String email;
    private String phone;
    private String dept;
    private LocalDateTime requestDate;
    private List<String> roles; // ROLE_CODE 리스트
}
