package kr.co.sist.e_learning.payment;

import lombok.Data;

@Data
public class PaymentResponseDTO {
    private boolean success;
    private String message;
}

