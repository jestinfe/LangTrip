package kr.co.sist.e_learning.community;

public class CommunityPostDTO {

}
