package kr.co.sist.e_learning.admin.signup.repository;

public class AdminSignupRoleRepository {

}
