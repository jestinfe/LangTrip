package kr.co.sist.e_learning.admin.signup.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "ADMIN_SIGNUP_ROLE")
@Getter
@Setter
public class AdminSignupRole {

    @EmbeddedId
    private AdminSignupRoleId id;

    @ManyToOne
    @MapsId("requestId")
    @JoinColumn(name = "REQUEST_ID")
    private AdminSignupRequest signupRequest;

    @ManyToOne
    @JoinColumn(name = "ROLE_CODE", insertable = false, updatable = false)
    private RoleDict roleDict;
}
