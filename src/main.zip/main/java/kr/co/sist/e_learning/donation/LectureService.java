package kr.co.sist.e_learning.donation;

public interface LectureService {
	 LectureDetailDTO getLectureDetail(String courseSeq);
}
