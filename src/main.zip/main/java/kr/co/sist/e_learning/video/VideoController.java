package kr.co.sist.e_learning.video;

import org.springframework.stereotype.Controller;

@Controller
public class VideoController {

}
