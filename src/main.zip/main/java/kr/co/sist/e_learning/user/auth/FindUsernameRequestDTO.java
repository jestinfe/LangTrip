package kr.co.sist.e_learning.user.auth;

import lombok.Getter;

@Getter
public class FindUsernameRequestDTO {
	 private String email;
}
