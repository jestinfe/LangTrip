package kr.co.sist.e_learning.admin.signup.repository;

import kr.co.sist.e_learning.admin.signup.entity.AdminSignupRequest;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AdminSignupRequestRepository extends JpaRepository<AdminSignupRequest, String> {
    List<AdminSignupRequest> findByStatus(String status); // PENDING만 조회
}
