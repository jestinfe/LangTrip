package kr.co.sist.e_learning.admin.signup.entity;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "ADMIN_SIGNUP_REQUEST")
@Getter
@Setter
public class AdminSignupRequest {

    @Id
    @Column(name = "REQUEST_ID")
    private String requestId;

    @Column(name = "ADMIN_NAME")
    private String adminName;

    @Column(name = "EMAIL")
    private String email;

    @Column(name = "PHONE")
    private String phone;

    @Column(name = "PASSWORD_HASH")
    private String passwordHash;

    @Column(name = "DEPT")
    private String dept;

    @Column(name = "STATUS")
    private String status; // PENDING / APPROVED / REJECTED

    @Column(name = "REQUEST_DATE")
    private LocalDateTime requestDate;

    @OneToMany(mappedBy = "signupRequest", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<AdminSignupRole> roles;
}
