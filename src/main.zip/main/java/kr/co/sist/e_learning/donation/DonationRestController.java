package kr.co.sist.e_learning.donation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import kr.co.sist.e_learning.user.auth.SimpleResponseDTO;
import kr.co.sist.e_learning.mypage.FundingService; // FundingService import 추가
import kr.co.sist.e_learning.mypage.FundingDTO; // FundingDTO import 추가
import java.util.List; // List import 추가

@RestController
@RequestMapping("/api/donation")
public class DonationRestController {


    @Autowired
    private DonationService donationService;

    @Autowired // FundingService 주입 추가
    private FundingService fundingService;

    @PostMapping
    public ResponseEntity<?> donate(@RequestBody DonationRequestDTO dto, Authentication authentication) {
        try {
            if (authentication == null || authentication.getPrincipal() == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(new SimpleResponseDTO(false, "사용자가 인증되지 않았습니다.", null));
            }

            Object principal = authentication.getPrincipal();
            Long userSeq;

            // 타입을 안전하게 처리하도록 개선
            if (principal instanceof Long) {
                userSeq = (Long) principal;
            } else if (principal instanceof String) {
                userSeq = Long.valueOf((String) principal);
            } else {
                throw new IllegalStateException("지원하지 않는 Principal 타입: " + principal.getClass());
            }


            // 후원 처리
            DonationDTO donationResult = donationService.donate(userSeq, dto);

            if (donationResult == null) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(new SimpleResponseDTO(false, "후원 처리 실패", null));
            }

            return ResponseEntity.ok(donationResult);

        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest()
                    .body(new SimpleResponseDTO(false, "유효하지 않은 인증 정보입니다.", null));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(new SimpleResponseDTO(false, "후원 처리 중 오류가 발생했습니다.", null));
        }
    }

    @GetMapping("/donations") // 새로운 GET 엔드포인트 추가
    public ResponseEntity<?> getDonations(@RequestParam("type") String donationType, Authentication authentication) {
        try {
            if (authentication == null || authentication.getPrincipal() == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(new SimpleResponseDTO(false, "사용자가 인증되지 않았습니다.", null));
            }

            Object principal = authentication.getPrincipal();
            Long userSeq;

            if (principal instanceof Long) {
                userSeq = (Long) principal;
            } else if (principal instanceof String) {
                userSeq = Long.valueOf((String) principal);
            } else {
                throw new IllegalStateException("지원하지 않는 Principal 타입: " + principal.getClass());
            }

            List<FundingDTO> donations;
            if ("given".equals(donationType)) {
                donations = fundingService.getUserFundings(userSeq);
            } else if ("received".equals(donationType)) {
                donations = fundingService.getReceivedDonations(userSeq);
            } else {
                return ResponseEntity.badRequest()
                        .body(new SimpleResponseDTO(false, "유효하지 않은 후원 유형입니다.", null));
            }

            return ResponseEntity.ok(donations);

        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest()
                    .body(new SimpleResponseDTO(false, "유효하지 않은 인증 정보입니다.", null));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(new SimpleResponseDTO(false, "후원 내역 조회 중 오류가 발생했습니다.", null));
        }
    }
}