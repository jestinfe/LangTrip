package kr.co.sist.e_learning.community;

import org.springframework.stereotype.Service;

@Service
public class CommunityPostService {

}
