package kr.co.sist.e_learning.admin.member;

import org.springframework.stereotype.Controller;

@Controller
public class AdminMemberController {

}
